
<ul>
    <li><a href="create.php">Create Employee</a></li>
    <li><a href="retrive.php">Employee List</a></li>
</ul>


